package org.acme.quickstart;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class TransactionalResourceIT extends TransactionalResourceTest {

    // Execute the same tests but in native mode.
}
