package org.acme.sns;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class SnsResourcesIT extends SnsResourcesTest {
    // Runs the same tests as the parent class
}
