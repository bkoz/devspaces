Quarkus guide: https://quarkus.io/guides/funqy-http
