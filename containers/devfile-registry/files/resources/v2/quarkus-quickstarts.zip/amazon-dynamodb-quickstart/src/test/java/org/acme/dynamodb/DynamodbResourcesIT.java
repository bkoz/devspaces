package org.acme.dynamodb;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class DynamodbResourcesIT extends DynamodbResourcesTest {
    // Runs the same tests as the parent class
}
