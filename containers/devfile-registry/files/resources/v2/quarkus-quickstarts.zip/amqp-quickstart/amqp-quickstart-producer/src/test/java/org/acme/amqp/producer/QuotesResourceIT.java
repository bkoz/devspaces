package org.acme.amqp.producer;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class QuotesResourceIT extends QuotesResourceTest {

}
